package HotelLogin;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import hotelbookingPageFactory.hotelbookingPageFactory;

public class StepDefs {
	hotelbookingPageFactory pagefactoryobj;
	WebDriver driver;
	@Given("^User launches the browser and opens the login page$")
	public void user_launches_the_browser_and_opens_the_login_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\utdwived\\Desktop\\BDD Jar Files\\chromedriver_win32//chromedriver.exe");
		
		driver=new ChromeDriver();
		driver.get("file:///C:/Users/utdwived/Desktop/login.html");
		driver.manage().window().maximize();
		
	   
	}

	@When("^Verify login page heading as \"([^\"]*)\"$")
	public void verify_login_page_heading_as(String arg1) throws Throwable {
	    String head=driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/h1")).getText();
	    System.out.println(head);
	    assertEquals("Hotel Booking Application", head);
	}

	@Then("^user enter invalid username and password$")
	public void user_enter_invalid_username_and_password() throws Throwable {
		driver.findElement(By.name("userName")).sendKeys("capgemini");
		//driver.findElement(By.name("userPwd")).sendKeys("capg1234");
		driver.findElement(By.className("btn")).click();
		
	}
	
	@Then("^User get error message$")
	public void user_get_error_message() throws Throwable {
	    
		   String errmsg= driver.findElement(By.id("pwdErrMsg")).getText();
		   String experrmsg="* Please enter password.";
		   assertEquals(errmsg,experrmsg);
		   driver.close();
	}
	
	@When("^User enter \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_enter_and(String arg1, String arg2) throws Throwable {
		driver.findElement(By.name("userName")).sendKeys("capgemini");
		driver.findElement(By.name("userPwd")).sendKeys("capg1234");
		driver.findElement(By.className("btn")).click();
		
	    
	}

	@Then("^user get redirected to booking form page$")
	public void user_get_redirected_to_booking_form_page() throws Throwable {
	     driver.get("file:///C:/Users/utdwived/Desktop/BDD/hotelbooking.html");
	     pagefactoryobj= new hotelbookingPageFactory(driver);
	     pagefactoryobj.setFormfirstname("Alphy");
	 	//Thread.sleep(500);
	 	//driver.close();
	 	pagefactoryobj.setFormlastname("Thomson");
	 	pagefactoryobj.setFormemail("abc@gmail.com");
	 	pagefactoryobj.setFormfone("9234567890");
	 	pagefactoryobj.setFormaddress("Whitefield,Bangalore");
	 	pagefactoryobj.setFormcity("Bangalore");
	 	pagefactoryobj.setFormstate("Karnataka");
	 	pagefactoryobj.setFormnoofpersons("3");
	 	pagefactoryobj.setFormcardholdername("Alphy T");
	 	pagefactoryobj.setFormdebitCardno("13459045872");
	 	pagefactoryobj.setFormCVV("123");
	 	pagefactoryobj.setFormexpmonth("Jan");
	 	pagefactoryobj.setFormexpyear("2020");
	 	
	 	pagefactoryobj.setConfirmbtn();
	 	//driver.findElement(By.xpath("//*[@id=\"btnPayment\"]")).click();
	 	Thread.sleep(2000);
	 	
	 
	}
	
	@Then("^user get success message$")
	public void user_get_success_message() throws Throwable {
		 String actualmsg=pagefactoryobj.getsuccessmsg();
	     String expectedmsg="Booking Completed!";
	     assertEquals(actualmsg,expectedmsg);
	     driver.close();
	}
	
	@Given("^user is on registration form page$")
	public void user_is_on_registration_form_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\utdwived\\Desktop\\BDD Jar Files\\chromedriver_win32//chromedriver.exe");
		
		driver=new ChromeDriver();
		driver.get("file:///C:/Users/utdwived/Desktop/BDD/hotelbooking.html");
	    
	}
	@When("^user enters incomplete deatail and get error message$")
	public void user_enters_incomplete_deatail_and_get_error_message() throws Throwable {
		pagefactoryobj= new hotelbookingPageFactory(driver);
	     pagefactoryobj.setFormfirstname("Alphy");
	 	//Thread.sleep(500);
	 	//driver.close();
	 	//pagefactoryobj.setFormlastname("Thomson");
	 	pagefactoryobj.setFormemail("abc@gmail.com");
	 	pagefactoryobj.setFormfone("9234567890");
	 	pagefactoryobj.setFormaddress("Whitefield,Bangalore");
	 	pagefactoryobj.setFormcity("Bangalore");
	 	pagefactoryobj.setFormstate("Karnataka");
	 	pagefactoryobj.setFormnoofpersons("3");
	 	pagefactoryobj.setFormcardholdername("Alphy T");
	 	pagefactoryobj.setFormdebitCardno("13459045872");
	 	pagefactoryobj.setFormCVV("123");
	 	pagefactoryobj.setFormexpmonth("Jan");
	 	pagefactoryobj.setFormexpyear("2020");
	 	pagefactoryobj.setConfirmbtn();
	 	//driver.findElement(By.xpath("//*[@id=\"btnPayment\"]")).click();
	 	Thread.sleep(1000);
	 	/*Alert actualmsg1=driver.switchTo().alert();
	 	String messg=actualmsg1.getText();
	 	Thread.sleep(2000);
	 	actualmsg1.accept();
	 	driver.close();*/

	 	String actualmsg1=driver.switchTo().alert().getText();
	    String expectedmsg2="Please fill the Last Name";
	      
	    //driver.switchTo().alert().accept();
	    System.out.println(actualmsg1);
	    //driver.close();
	    assertEquals(expectedmsg2,actualmsg1);
	    System.out.println("hi");
	    driver.close();
	   
	   
	    

	}


	
	@When("^user enter invalid detail$")
	public void user_enter_invalid_detail() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\utdwived\\Desktop\\BDD Jar Files\\chromedriver_win32//chromedriver.exe");
		
		driver=new ChromeDriver();
		pagefactoryobj= new hotelbookingPageFactory(driver);
		driver.get("file:///C:/Users/utdwived/Desktop/BDD/hotelbooking.html"); 
		pagefactoryobj.setFormfirstname("Alphy");
	 	//Thread.sleep(500);
	 	//driver.close();
	 	pagefactoryobj.setFormlastname("Thomson");
	 	pagefactoryobj.setFormemail("abc@gmail.com");
	 	pagefactoryobj.setFormfone("9234567890");
	 	pagefactoryobj.setFormaddress("Whitefield,Bangalore");
	 	pagefactoryobj.setFormcity("Pune");
	 	pagefactoryobj.setFormstate("Karnataka");
	 	pagefactoryobj.setFormnoofpersons("");
	 	pagefactoryobj.setFormcardholdername("Alphy T");
	 	pagefactoryobj.setFormdebitCardno("13459045872");
	 	pagefactoryobj.setFormCVV("123");
	 	pagefactoryobj.setFormexpmonth("Jan");
	 	pagefactoryobj.setFormexpyear("");
	 	pagefactoryobj.setConfirmbtn();
	 	//driver.findElement(By.xpath("//*[@id=\"btnPayment\"]")).click();
	 	Thread.sleep(2000);
	 	 
	 	
	 	
	
	}

	@Then("^user get invalid detail error message$")
	public void user_get_invalid_detail_error_message() throws Throwable {
		
		/*Alert actualmsg3=driver.switchTo().alert();
	 	String mssg=actualmsg3.getText();
	 	Thread.sleep(2000);
	 	actualmsg3.accept();
		*/
		
		String actualmsg=driver.switchTo().alert().getText();
	     String expectedmsg="Please fill the expiration year";
	     System.out.println(actualmsg);
	      
	    //driver.switchTo().alert().accept();
	    
	    assertEquals(actualmsg,expectedmsg);
	    driver.close();
	    
		
	}






}
